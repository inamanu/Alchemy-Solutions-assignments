package demodemo;
import java.util.Scanner;

public class perfectNumber {
	public static void main(String[] args) {
		int i,divisor,sum=0;
		System.out.println("Enter the  number:");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		for(i=1 ; i< num ;i++) {
			divisor = num % i;
			if(divisor == 0) {
				sum = sum + i;
			}
		}//for
		if(sum == num) {
			System.out.println("Number is Perfect");
		}
		else {
			System.out.println("Number is not Perfect");
		}//else
	}//main
}//class