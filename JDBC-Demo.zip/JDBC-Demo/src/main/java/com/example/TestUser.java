package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Resource rs = new ClassPathResource("applicationContext.xml");  ------>step 1(i)
//		BeanFactory factory = new XmlBeanFactory(rs);                   ------>step 1(ii)
		
		ApplicationContext cx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//UserDAO doa = (UserDAO)factory.getBean("userDAO");            ------>step 2(required if step1 is there)
		UserDAO doa = (UserDAO) cx.getBean("userDAO");
		
		//int result = doa.saveUser(new User(101,"john@gmail.com","12345"));
		//System.out.println(result);
		
		int result = doa.updateUser(new User(101,"john@gmail.com","11111"));
		System.out.println(result);
	}

}
