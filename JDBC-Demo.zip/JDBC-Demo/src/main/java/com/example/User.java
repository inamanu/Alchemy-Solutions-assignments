package com.example;

public class User {
	private int id;
	private String emial;
	private String password;
	
	User(){
		System.out.println("Default Constructor");
	}
	
	public User(int id, String email, String password) {
		super();
		this.id=id;
		this.emial=email;
		this.password=password;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmial() {
		return emial;
	}

	public void setEmial(String emial) {
		this.emial = emial;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
