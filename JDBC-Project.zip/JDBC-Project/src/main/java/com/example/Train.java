package com.example;

public class Train {
	private int trainNo;
	private String traineName;
	private String source;
	private String destination;
	//private Double ticketprice;
	
	Train(){
		System.out.println("Default Constructor");
	}
	
	public Train(int trainNo, String traineName, String source, String destination) {
		super();
		this.trainNo=trainNo;
		this.traineName=traineName;
		this.source=source;
		this.destination=destination;
	}
	
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	public String getTraineName() {
		return traineName;
	}
	public void setTraineName(String traineName) {
		this.traineName = traineName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
}
