package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTrain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext cx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//UserDAO doa = (UserDAO)factory.getBean("userDAO");            ------>step 2(required if step1 is there)
		TrainDAO doa = (TrainDAO) cx.getBean("trainDAO");
		
		//int result = doa.saveUser(new User(101,"john@gmail.com","12345"));
		//System.out.println(result);
		
		int result = doa.saveTrain(new Train(1010,"Purushotam","BBSR","Punjab"));
		System.out.println(result);

	}

}
