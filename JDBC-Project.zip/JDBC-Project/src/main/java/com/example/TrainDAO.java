package com.example;

import org.springframework.jdbc.core.JdbcTemplate;

public class TrainDAO {
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public int saveTrain(Train train) {
		String query = "insert into Trains values("+train.getTrainNo()+",'"+train.getTraineName()+"','"+train.getSource()+"','"+train.getDestination()+"')";
		return jdbcTemplate.update(query);
	}
	public int updateTrain(Train train){
        String query = "update Trains set email = '" + train.getSource()+"',password='"+train.getDestination()+ "'where id ='"+train.getTrainNo()+"'";
        return jdbcTemplate.update(query);
    }
	public int deleteTrain(Train train) {
		String query = "delete from Trains where id = '"+train.getTrainNo()+"' ";
		return jdbcTemplate.update(query);
	}
	
}

