package javaexception;

public class TestExcep9 {

	public static void main(String[] args) {
		try {
			String msg = "hello";
						//01234
			System.out.println(1);
			try {
				System.out.println(2);
				System.out.println(msg.charAt(7));
				System.out.println(3);
			}catch(StringIndexOutOfBoundsException e) {
				System.out.println(e);
			}
			System.out.println(4);
		}catch (Exception ex) {
			System.out.println("Exception is : "+ex);
		}
	}
}
