package javaexception;

class InvalidUserException extends Exception{
	public InvalidUserException(String msg) {
		super(msg);
	}
}

public class CustomException {
	
	static void validateUser(String username,String password) throws InvalidUserException{
		if(username.equals("admin") && password.equals("admin123")) {
			System.out.println("Validation done");
		}else {
			throw new InvalidUserException("Invalid user");
		}
	}

	public static void main(String[] args) {
		try {
			validateUser("admin","admin1234");
		} catch (InvalidUserException e) {
			// TODO Auto-generated catch block
			//System.out.println(e.getMessage());
			e.printStackTrace();
			//System.out.println("Error Occured");
		}

	}

}
