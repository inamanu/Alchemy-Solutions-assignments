package javaexception;

public class TestExcep5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 40;
		try {
			System.out.println(40/0);
		}catch (NullPointerException e) {
			System.out.println("I am null");
			System.out.println(e);
		}
	}

}
