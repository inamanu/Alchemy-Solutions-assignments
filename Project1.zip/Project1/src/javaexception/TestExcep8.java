package javaexception;

public class TestExcep8 {

	public static void main(String[] args) {
		int num = 40;
		String str = null;
		int[] n = {10,20,30};
		try {
			System.out.println(n[6]);
			System.out.println(str.length());
			System.out.println(40/0);
		}catch (NullPointerException e) {
			System.out.println("I am null");
			System.out.println(e);
		}
		catch(ArithmeticException e) {
			System.out.println("I am inside arithmetic");
			System.out.println(e);
		}catch(Exception e) {
			System.out.println("exception occured "+e);
		}

	}

}
