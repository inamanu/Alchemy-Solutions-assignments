package javaexception;

public class TestExcep6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 40;
		String str = null;
		try {
			System.out.println(str.length());
			System.out.println(40/0);
		}catch (NullPointerException e) {
			System.out.println("I am null");
			System.out.println(e);
		}
		catch(ArithmeticException e) {
			System.out.println("I am inside arithmetic");
			System.out.println(e);
		}
	}

}
