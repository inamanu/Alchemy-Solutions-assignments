package javaexception;

import java.util.Scanner;

public class TestExcep12 {
	
	static boolean checkMark(int num) {
		if(num < 0) {
			throw new ArithmeticException("please enter a valid mark");
		}else {
			return true;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your mark");
		int result = sc.nextInt();
		
		System.out.println(1);
		
		try {
			if(checkMark(result)) {
				
				System.out.println("Entered result = "+result);
			}
		}catch(Exception e) {
			System.out.println("error occured - "+e.getMessage());
		}
		System.out.println(2);
		sc.close();
	}

}
