package javaexception;

class A1{
	int num;
	A1(int num){
		this.num = num;
	}
	void display() {
		System.out.println("Number is : "+num);
	}
}
class B1 extends A1{
	B1(int num){
		super(num);
	}
	void display() {
		System.out.println("Number is : "+num+" from class B");
	}
}

public class TestExcep10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b1 = new B1(20);
		A1 a1 = new A1(30);
		a1=b1;
		a1.display();
		A1 obj3 = new A1(40);
		B1 obj = (B1)obj3;
	}

}
