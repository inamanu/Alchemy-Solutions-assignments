package javaexception;

import java.io.IOException;

class A11{
	void display() throws IOException{
		System.out.println("msg from display");
		throw new IOException("Input Output error");
	}
}

public class TestExcep14 {
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		A11 obj = new A11();
		obj.display();
	}

}
