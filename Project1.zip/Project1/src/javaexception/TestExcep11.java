package javaexception;

public class TestExcep11 {
	
	static boolean checkNumber(int num) {
		if(num ==0) {
			throw new ArithmeticException("Divided by zero");
		}else {
			return true;
		}
	}

	public static void main(String[] args) {
		int num1 = 200;
		int num2 = 0;
		int result;
		
		System.out.println(1);
		
		try {
			if(checkNumber(num2)) {
				result = num1/num2;
				System.out.println("results = "+result);
			}
		}catch(Exception e) {
			System.out.println("error occured - "+e.getMessage());
		}
		System.out.println(2);
	}

}
