package javaexception;

public class TestExcep3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = null;
		System.out.println(name.length());
	}

}
