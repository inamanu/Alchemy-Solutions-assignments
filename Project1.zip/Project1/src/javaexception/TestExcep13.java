package javaexception;

public class TestExcep13 {
	
	static void task() throws NullPointerException
	{
		System.out.println("within the task");
		throw new NullPointerException("No value present");
	}


	public static void main(String[] args) {
		try {
			task();
		}catch(NullPointerException e) {
			System.out.println("Caught in main "+e.getMessage());
		}
	}

}
