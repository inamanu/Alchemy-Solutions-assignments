package javaoperators;

public class Test1 {
	public static void main(String[] args) {
		int num1=60;
		int num2=30;
		
		System.out.println(num1+num2);
		System.out.println(num1-num2);
		System.out.println(num1*num2);
		System.out.println(num1/num2);
	}
}
