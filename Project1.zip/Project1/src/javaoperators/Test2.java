package javaoperators;

public class Test2 {
public static void main(String[] args) {
	int num = 10;
	int num2 = 10;
	num++;
	num2--;
	System.out.println(num);
	System.out.println(num2);
}
}
