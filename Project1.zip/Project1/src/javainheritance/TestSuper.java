package javainheritance;

class Bike{
	int speed = 100;
	Bike(){
		System.out.println("Bike is running at speed "+speed+" km/hr");
	}
	void display() {
		System.out.println("This message is from Display");
	}
}

class Honda extends Bike{
	int speed = 200;
	Honda(){
		super();
		System.out.println("Honda is a fine bike.");
	}
	void show() {
		System.out.println(super.speed);
		System.out.println(this.speed);
		super.display();	
	}
}

public class TestSuper {

	public static void main(String[] args) {
		Honda obj = new Honda();
		obj.show();
	}

}
