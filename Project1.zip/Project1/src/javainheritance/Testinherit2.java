package javainheritance;

class A1 {
	int number = 200;
}

class B1 extends A1{
	int number2 = 100;
	int res = number+number2;
	void display() {
		System.out.println(res);
	}
}

public class Testinherit2 {

	public static void main(String[] args) {
		B1 obj = new B1();
		obj.display();

	}

}
