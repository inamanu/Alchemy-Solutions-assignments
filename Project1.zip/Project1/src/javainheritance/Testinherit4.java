package javainheritance;

class A0{
	int num1 = 90;
}

class B0 extends A0{
	int num2 = 30;
	int res;
	
	void cal() {
		res = num1*num2;
		System.out.println(res);
	}
}
class C0 extends A0{
	int num2 = 40;
	int res;
	void cal() {
		res=num1/num2;
		System.out.println(res);
	}
}

class D0 extends C0{
	void display() {
		System.out.println("From D0");
		cal();
	}
}
public class Testinherit4 {

	public static void main(String[] args) {
		D0 obj = new D0();
		obj.display();
	}

}
