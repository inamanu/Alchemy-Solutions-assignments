package javapolymorphism;

class Calculation1{
	int addition(int x,int y) {
		return x+y;
	}
	
	double addition(double x,double y) {
		return x+y;
	}
}

public class Test2 {

	public static void main(String[] args) {
		Calculation1 obj = new Calculation1();
		System.out.println(obj.addition(30, 30));
		System.out.println(obj.addition(29.2,30.8));

	}

}
