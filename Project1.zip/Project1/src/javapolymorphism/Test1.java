package javapolymorphism;

class Calculation{
	int addition(int x,int y) {
		return x+y;
	}
	
	int addition(int x,int y,int z) {
		return x+y+z;
	}
}

public class Test1 {

	public static void main(String[] args) {
		Calculation obj = new Calculation();
		System.out.println(obj.addition(30, 30));
		System.out.println(obj.addition(30,30,30));

	}

}
