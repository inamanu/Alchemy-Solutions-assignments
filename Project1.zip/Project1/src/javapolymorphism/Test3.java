package javapolymorphism;

class A1{
	void display() {
		System.out.println("A1 gets executed");
	}
}

class B1 extends A1{
	void display() {
		System.out.println("B1 gets executed");
	}
}

public class Test3 {

	public static void main(String[] args) {
		B1 obj = new B1();
		obj.display();

	}

}
