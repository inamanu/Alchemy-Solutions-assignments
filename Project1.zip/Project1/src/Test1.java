
public class Test1 {
	public static void main(String[] args) {
		int num1=20;
		int num2=30;
		int res;
		
		res = num1+num2;
		
		System.out.println("The result of "+ num1 + " and "+ num2 + " is: "+ res);
	}
}
