package javaio;

import java.io.IOException;
import java.io.InputStreamReader;

public class Test1 {

	public static void main(String[] args) throws IOException {
		InputStreamReader ip = null;
		ip = new InputStreamReader(System.in);
		System.out.println("Enter the characters, '0' to exit");
		char c;
		
		do {
			c = (char)ip.read();
			System.out.println(c);
		}while(c!=0);

	}

}
