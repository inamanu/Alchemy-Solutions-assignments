package javaio;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputStream ip = null;
		try {
			ip = new FileInputStream("C:\\Users\\User76\\Documents\\Demo\\CHECK.txt");
			
			int i;
			while((i = ip.read())!= -1) {
				System.out.println((char)i);
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
