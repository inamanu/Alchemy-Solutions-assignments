package javaio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("C:\\Users\\User76\\Documents\\Demo\\CHECK.txt");
		
		try {
			FileReader r = new FileReader(f);
			int i;
			while( (i = r.read())!=-1) {
				System.out.println((char)i);
			}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
