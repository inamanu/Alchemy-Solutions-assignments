package javaio;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg = "Welcome to my Application";
		try {
			FileWriter fw = new FileWriter("C:\\Users\\User76\\eclipse-workspace\\Project1\\src\\javaio\\Text1");
			
			JSONObject obj = new JSONObject();
			
			obj.put("id", 1);
			obj.put("Name", "John");
			obj.put("Age", 23);
			fw.write(obj.toJSONString());
			fw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done...");
	}

}
