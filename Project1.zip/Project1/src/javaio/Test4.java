package javaio;

import java.io.FileWriter;
import java.io.IOException;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg = "Welcome to my Application";
		try {
			FileWriter fw = new FileWriter("C:\\Users\\User76\\eclipse-workspace\\Project1\\src\\javaio\\Text1");
			fw.write(msg);
			fw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done...");

	}

}
