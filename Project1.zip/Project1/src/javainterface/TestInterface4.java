package javainterface;

interface Add{
	void addition(int x, int y);
}

public class TestInterface4 {

	public static void main(String[] args) {
		Add obj = new Add(){
			public void addition(int x, int y) {
				int res;
				res = x+y;
				System.out.println("Sum = "+res);
			}
		};
		obj.addition(20,30);
	}

}
