package javainterface;

interface I4{
	void add();
}

interface I5 extends I4{
	void mul();
}
public class TestInterface3 implements I4, I5 {

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		System.out.println("Multiplication");
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("Addition");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestInterface3 obj = new TestInterface3();
		obj.add();
		obj.mul();

	}

}
