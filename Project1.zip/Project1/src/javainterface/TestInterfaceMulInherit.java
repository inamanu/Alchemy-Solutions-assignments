package javainterface;

interface I2{
	void show();
}

interface I3{
	void display();
}

public class TestInterfaceMulInherit implements I2,I3 {


	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Message from Display");
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Message from Show");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestInterfaceMulInherit obj = new TestInterfaceMulInherit();
		obj.display();
		obj.show();
	}

}
