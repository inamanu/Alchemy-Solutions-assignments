package javainterface;

interface I1{
	void display();
	void calculate();
}

public class TestInterface implements I1{

	@Override
	public void display() {
		System.out.println("Message from Display");
		
	}

	@Override
	public void calculate() {
		System.out.println("Message from Calculate");
		
	}
	
	public static void main(String[] args) {
		TestInterface obj = new TestInterface();
		obj.calculate();
		obj.display();
	}

}
