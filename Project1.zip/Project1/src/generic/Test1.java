package generic;


class A<T>{
	T num;
	
	A(T num){
		this.num = num;
	}
	
	T getObject() {
		return num;
	}
}

public class Test1 {

	public static void main(String[] args) {
		A<Integer> obj = new A<Integer>(20);
		System.out.println(obj.getObject());
		
		A<String> obj1 = new A<String>("John");
		System.out.println(obj1.getObject());

	}

}
