package generic;

import java.util.ArrayList;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al = new ArrayList<String>();
		al.add("John");
		al.add("jack");
		al.add("happy");
		//al.add(10);
	}

}
