package generic;
class Calculate<any,any2>{
	any num;
	//any2 res;
	//any3 c;
	any2 res;
	//int r;
	
	Calculate(any num,any2 res){
		this.num = num;
		this.res = res;
		//this.c = c;
	}
	
	void add() {
		//System.out.println(res+num);
		//r = res + num;
		//return res+num;
	}
}

public class Test3 {

	public static void main(String[] args) {
		Calculate<Integer,Integer> obj = new Calculate<Integer,Integer>(20,30);
		//System.out.println(obj.add());
		obj.add();
	}

}


