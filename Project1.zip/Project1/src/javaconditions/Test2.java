package javaconditions;

import java.util.Scanner;

public class Test2 {
	public static void main(String[] args) {
		int age;
		Scanner sc = new Scanner(System.in);
		age = sc.nextInt();
		
		if(age>=18)
			System.out.println("Eligible to vote");
		else
			System.out.println("Not eligible to vote");
		sc.close();
	}
}
