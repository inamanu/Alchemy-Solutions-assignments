package javaconditions;

public class Test1 {
	public static void main(String[] args) {
		int age = 15;
		if(age>=18)
			System.out.println("Eligible to vote");
		else
			System.out.println("Not Eligible to vote");
	}
}
