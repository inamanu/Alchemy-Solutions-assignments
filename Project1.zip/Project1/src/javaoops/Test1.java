package javaoops;


class Cars{
	String brand = "SUVs";
	String model = "Range Rover";
	String color = "Black";
	double price = 6300000.90;
}

class Emp{
	String name = "Jackson";
	int age = 56;
	String address = "Park street";
	double salary = 50000.76;
}

class Company{
	String c_name = "THBS";
	String department = "Software";
	String address = "Banglore";
}

public class Test1 {

	public static void main(String[] args) {
		Cars obj = new Cars();
		Emp obj2 = new Emp();
		Company obj3 = new Company();
		System.out.println(obj.brand);
		System.out.println(obj.model);
		System.out.println(obj.color);
		System.out.println(obj.price);
		System.out.println(" ");
		System.out.println("==========================");
		System.out.println(" ");
		System.out.println(obj2.name);
		System.out.println(obj2.age);
		System.out.println(obj2.address);
		System.out.println(obj2.salary);
		System.out.println(" ");
		System.out.println("==========================");
		System.out.println(" ");
		System.out.println(obj3.c_name);
		System.out.println(obj3.address);
		System.out.println(obj3.department);
		System.out.println(" ");
		System.out.println("==========================");
		

	}

}
