package javaoops;

class Person{
	int id;
	String name;
	
	Person(){
		id = 101;
		name = "Jack";
	}
	void display() {
		System.out.println(id+" "+name);
	}
}

public class Test4 {

	public static void main(String[] args) {
		Person obj = new Person();
		obj.display();

	}

}
