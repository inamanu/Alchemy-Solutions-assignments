package javaoops;

class Employee{
	int id;
	String name;
	String designation;
	int Salary;
	String address;
	
	Employee(){
		System.out.println("Default Executed");
	}
	
	Employee(int id,String name,String designation){
		this.id = id;
		this.name = name;
		this.designation = designation;
	}
	Employee(int id,String name,String address,int Salary){
		this.id = id;
		this.name = name;
		this.address = address;
		this.Salary= Salary;
	}
	
	
	void display() {
		System.out.println(id+" "+name+" "+designation);
	}
	void show() {
		System.out.println(id+" "+name+" "+address+" "+Salary);
	}
}

public class Test6 {

	public static void main(String[] args) {
		Employee zz1 = new Employee();
		Employee zz2 = new Employee(101,"Jackson","Manager");
		Employee zz3 = new Employee(300,"Micheal","Banglore",50000);
		zz2.display();
		zz3.show();
	}

}