package javaoops;

class Book{
	int book_id = 101;
	String b_name = "Java";
	
	void display() {
		System.out.println(book_id+ " " + b_name);
	}
}

public class Test2 {

	public static void main(String[] args) {
		Book b = new Book();
		b.display();

	}

}
