package javaoops;

class Book1{
	
	Book1(){
		System.out.println("Executed");
	}
}

public class Test3 {
	public static void main(String[] args) {
		Book1 b1 = new Book1();
		Book1 b2 = new Book1();
	}

}
