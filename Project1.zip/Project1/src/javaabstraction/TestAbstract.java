package javaabstraction;

abstract class Shape{
	int l; 
	int b;
	
	Shape(int l, int b){
		this.l=l;
		this.b=b;
	}
	abstract void area();
}

class Triangle extends Shape{
	Triangle(int l, int b){
		super(l,b);
	}
	@Override
	void area() {
		double res;
		res = (0.5) * (l*b);
		System.out.println(res);
	}
}

class Rectangle extends Shape{
	Rectangle(int l, int b){
		super(l,b);
	}
	@Override
	void area() {
		double res;
		res = l*b;
		System.out.println(res);
	}
}


public class TestAbstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle obj = new Triangle(30, 2);
		obj.area();
		Rectangle obj2 = new Rectangle(30, 2);
		obj2.area();

	}

}
