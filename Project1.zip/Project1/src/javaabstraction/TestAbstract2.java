package javaabstraction;


abstract class A1 {
	
	void display() {
		System.out.println("Message from display");
	}
	abstract void calculate();
	abstract void discount();
}

public class TestAbstract2 extends A1{
	
	@Override
	void calculate() {
		System.out.println("Message from calculate");
	}
	
	@Override
	void discount() {
		System.out.println("Message from discount");
	}
	public static void main(String[] args) {
		
		TestAbstract2 obj = new TestAbstract2();
		obj.discount();
		obj.calculate();
		obj.display();
	}

}

