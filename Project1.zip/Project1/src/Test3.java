
public class Test3 {
	public static void main(String[] args) {
		int marks[] = {10,20,30,40,50,60};
		System.out.println(marks[0]);
	}
}
