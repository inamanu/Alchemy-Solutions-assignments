
public class Test2 {
	public static void main(String[] args) {
		int num = 100;
		double salary = 981.12;
		char ch = 'A';
		boolean flag = true;
		
		System.out.println(num);
		System.out.println(salary);
		System.out.println(ch);
		System.out.println(flag);
	}
}
