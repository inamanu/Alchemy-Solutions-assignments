package javaencap;

public class TestEncap {

	public static void main(String[] args) {
		//User u1 = new User();
		
		//u1.setUserName("Jackson");
		//u1.setPassword("Jackson123");
		//System.out.println(u1.getUserName());
		//System.out.println(u1.getPassword());
		
		//User u2 = new User();
		
		//u2.setUserName("Micheal");
		//u2.setPassword("micheal123");
		//System.out.println(u2.getUserName());
		//System.out.println(u2.getPassword());
		
		Product p1 = new Product();
		
		p1.setId(101);
		p1.setName("Laptop");
		p1.setPrice(70000);
		
		System.out.println(p1.getId()+" "+p1.getName()+" "+p1.getPrice());
		
		Product p2 = new Product();
		
		p2.setId(101);
		p2.setName("Laptop");
		p2.setPrice(70000);
		
		System.out.println(p2.getId()+" "+p2.getName()+" "+p2.getPrice());
		
		
	}

}
