package javawrapper;

public class Test2 {

	public static void main(String[] args) {
		Character ch = 'a';
		char c = ch;
		System.out.println(ch);
		System.out.println(c);

	}

}
