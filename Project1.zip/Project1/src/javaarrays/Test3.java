package javaarrays;

public class Test3 {

	public static void main(String[] args) {
		int arr[] = {5,10,15,20,25};
		
		for(int i : arr)
			System.out.println(i);
	}

}
