package java_practise;

import java.util.Scanner;

public class StringPalindrome {
	
	static boolean checkPalindrom(String s) {
		int i = 0;
		int j = s.length() - 1;
		//System.out.println(j);
		while(i<j) {
			if (s.charAt(i) != s.charAt(j)) 
				return false;	
			i++;
			j--;
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String to check palindrome");
		String s = sc.nextLine();
		boolean a = checkPalindrom(s);
		if (a == false)
			System.out.println("Entered String is not a Palindrome");
		else 
			System.out.println("Entered String is a Palindrome");
		//String ab;
		//ab = s.reverse();
		sc.close();
		
	}

}
