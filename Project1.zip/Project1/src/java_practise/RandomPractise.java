package java_practise;

import java.util.Scanner;

public class RandomPractise {

	public static void main(String[] args) {
		String c = "Y";
		Scanner sc = new Scanner(System.in);
		int day = sc.nextInt();
		while (c == "Y") {
			switch(day) {
			case 1:
				System.out.println("Monday");
				break;
			case 2:
				System.out.println("Tuesday");
				break;
			case 3:
				System.out.println("Wednesday");
				break;
			case 4:
				System.out.println("Thursday");
				break;
			case 5:
				System.out.println("Friday");
				break;
			case 6:
				System.out.println("Saturday");
				break;
			case 7:
				System.out.println("Sunday");
				break;
			default:
				System.out.println("Please enter a no. between 1 to 7");
			}
			System.out.println("Y to continue, N to stop");
			String ca = sc.next(); 
			if (ca == "N") {
				c = "N";
			}
			
		}

	}

}
