package java_practise;

import java.util.Scanner;

public class stringPalindrome2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String original_str;
		String reverse_str = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a String");
		original_str = sc.nextLine();
		//System.out.println(original_str.length());
		for( int i = original_str.length() - 1 ; i>=0; i--) {
			reverse_str = reverse_str + original_str.charAt(i);
			//System.out.println(reverse_str);
		}
		if (original_str.equals(reverse_str))
			System.out.println("Is a Palindrome");
		else
			System.out.println("Is not a palindrome");
		
		sc.close();
	}

}
