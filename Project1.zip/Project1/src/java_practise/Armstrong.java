package java_practise;

import java.util.Scanner;

public class Armstrong {
	
	public static void main(String[] args) {
		int number , originalNumber, remainder, result = 0,n = 0;
		System.out.println("Enter any number");
		Scanner sc = new Scanner(System.in);
		number = sc.nextInt();
		originalNumber = number;
		
		for(;originalNumber!=0; originalNumber /= 10,++n)
			originalNumber = number;
		
		for(;originalNumber!=0; originalNumber /= 10) {
			remainder = originalNumber%10;
			result += Math.pow(remainder,n);
		}
		if (result == number) {
			System.out.println("Armstrong");
		}
		else
			System.out.println("Not an armstrong");

	}

}
