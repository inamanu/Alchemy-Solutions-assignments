package java_practise;

import java.util.Scanner;

public class Swapping {

	public static void main(String[] args) {
		System.out.println("Enter the value of 1st number to swap");
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		System.out.println("Enter the value of 2st number to swap");
		int y = sc.nextInt();
		System.out.println("Before swapping x= "+x+" y="+y);
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println("After swapping x= "+x+" y="+y);
		sc.close();
	}

}
