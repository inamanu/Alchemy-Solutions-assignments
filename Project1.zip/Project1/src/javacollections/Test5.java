package javacollections;

import java.util.Iterator;
import java.util.Vector;

public class Test5 {
	public static void main(String[] args) {
		Vector<String> obj = new Vector<String>();
		obj.add("John");
		obj.add("Alex");
		obj.add("Abhi");
		obj.add("Krish");
		
		Iterator it = obj.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		}
}
