package javacollections;

import java.util.Iterator;
import java.util.PriorityQueue;

public class Test7 {

	public static void main(String[] args) {
		PriorityQueue<String> pq = new PriorityQueue<String>();
		pq.add("Andrew");
		pq.add("Simon");
		pq.add("Alex");
		pq.add("Sandra");
		//pq.add(null);
		pq.add("Peter");
		
		Iterator it1 = pq.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
	}

}
