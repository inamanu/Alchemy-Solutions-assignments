package javacollections;

import java.util.Deque;
import java.util.LinkedList;

public class Test8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<String> obj = new LinkedList<String>();
		obj.add("Item1");
		obj.addFirst("Item2");
		obj.addLast("Item3");
		obj.push("Item4");
		System.out.println(obj);
		
		obj.pop();
		System.out.println("--------------------------------------------");
		System.out.println(obj);
		obj.pollFirst();
		System.out.println("--------------------------------------------");
		System.out.println(obj);
		//obj.pollLast();
		//System.out.println("--------------------------------------------");
		//System.out.println(obj);
		//obj.poll();
		//System.out.println("--------------------------------------------");
		//System.out.println(obj);
	}

}
