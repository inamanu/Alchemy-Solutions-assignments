package javacollections;

import java.util.Iterator;
import java.util.Stack;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> obj = new Stack<String>();
		obj.push("Ashish");
		obj.push("John");
		obj.push("Rekha");
		obj.push("Navin");
		obj.push("Rani");
		
		Iterator it = obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("--------------------------------------------");
		obj.pop();
		

		Iterator it2 = obj.iterator();
		while(it2.hasNext()) {
			System.out.println(it2.next());
			}
		}

}
