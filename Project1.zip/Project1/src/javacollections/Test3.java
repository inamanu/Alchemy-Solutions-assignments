package javacollections;

import java.util.ArrayList;
import java.util.Iterator;

public class Test3 {

	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<String>();
		a.add("abc");
		a.add("def");
		a.add("ghi");
		a.add("jkl");
		a.add("mnop");
		Iterator it = a.iterator();
		
		while(it.hasNext())
			System.out.println(it.next());
	}

}
