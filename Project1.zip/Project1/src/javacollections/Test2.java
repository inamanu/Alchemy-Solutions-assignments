package javacollections;

import java.util.ArrayList;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		al.add("xyz");
		
		for(int i =0;i<al.size();i++) {
			System.out.println(al.get(i));
		}
	}

}
