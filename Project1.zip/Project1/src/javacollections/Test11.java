package javacollections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Test11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> set = new HashSet<Integer>();
		
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		
		System.out.println(set);
		
		Iterator it1 = set.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
	}

}

