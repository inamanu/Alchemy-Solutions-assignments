package javacollections;

import java.util.HashMap;

public class Test13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "John");
		map.put(2, "Abhi");
		map.put(3, "Tony");
		map.put(4, "Radha");
		map.put(5, "Rohan");
		
		System.out.println(map.get(4));
	}

}
