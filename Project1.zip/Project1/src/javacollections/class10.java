package javacollections;

import java.util.HashSet;
import java.util.Set;

public class class10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set = new HashSet<String>();
		set.add("John");
		set.add("Jack");
		set.add("Joe");
		set.add("Julie");
		set.add("John");
		
		System.out.println(set);
	}

}
