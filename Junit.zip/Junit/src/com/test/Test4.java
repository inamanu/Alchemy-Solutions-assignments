package com.test;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.junit.Test;

import com.example.TestDemo4;

public class Test4 {
	@Test
	public void test() {

		Scanner sc = new Scanner(System.in);
		String user = sc.next();
		String pass = sc.next();
		assertEquals("Log in success",TestDemo4.val(user,pass));
		//assertEquals("Fields are blank",TestDemo4.val(" "," "));
		sc.close();
	}
}
