package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.example.*;
import com.example.TestDemo1;

public class Test2 {
	
	@Test
	public void testAdd() {
		assertEquals(("Jack"),TestDemo2.Set("Jack"));
		//assertEquals(40,TestDemo1.addition(30,30));
		//assertEquals(10,TestDemo1.sub(50,30));
	}
}
