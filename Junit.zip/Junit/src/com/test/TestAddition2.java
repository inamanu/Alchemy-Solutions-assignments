package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.TestDemo1;

public class TestAddition2 {
	
	@Before
	public void beforeTest() {
		System.out.println("Execute Before Test");
	}
	
	@Test
	public void testAdd() {
		System.out.println("Actual Test");
		assertEquals(60, TestDemo1.addition(30, 30));
	}
	
	@After
	public void afterTest() {
		System.out.println("Executed After Test");
	}
}
