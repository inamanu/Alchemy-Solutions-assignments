package com.test;

import static org.junit.Assert.assertEquals;
import com.example.*;
import org.junit.Test;
public class TestAddition {
	
	@Test
	public void testAdd() {
		assertEquals(60,TestDemo1.addition(30,30));
		//assertEquals(40,TestDemo1.addition(30,30));
		//assertEquals(10,TestDemo1.sub(50,30)) ;
		
	}
}
