package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.example.*;

public class Test3 {
	//int x=1;
	//String xar = "jack";
	@Test
	public void test() {
		assertEquals(("1 Jack"),TestDemo3.Set("1","Jack"));
		//assertEquals(40,TestDemo1.addition(30,30));
		//assertEquals(10,TestDemo1.sub(50,30));
	}
}