package com.example;

import java.util.Scanner;

class Z{
	public static String val(String user, String pass) {
		//System.out.println("id : "+x+" name: "+y);
		//return x + " " + y;
		if(user.equals("admin") && pass.equals("admin123")) {
			return "Log in success";
		}
		else if (user.equals(" ") && pass.equals(" ")) {
			return "Fields are blank";
		}
		else {
			return "Invalid User";
		}
	}
}

public class TestDemo4 extends Z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String user = sc.next();
		String pass = sc.next();
		//System.out.println("hello");
		String a = val(user,pass);
		System.out.println(a);
		
		}

}
