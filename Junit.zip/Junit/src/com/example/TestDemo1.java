package com.example;

class Calculation{
	public static int addition(int x, int y) {
		return x+y;
	}
	
	public static int sub(int x, int y) {
		return x-y;
	}
}
public class TestDemo1 extends Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Calculation obj = new Calculation();
		//System.out.println(obj.addition(30,30));
		//System.out.println(addition(30,30));
		System.out.println(sub(60,30));

	}

}
