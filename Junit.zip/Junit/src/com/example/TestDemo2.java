package com.example;

class S{
	public static String Set(String y) {
		return y;
	}
}

public class TestDemo2 extends S {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Set("Archit"));
	}

}
