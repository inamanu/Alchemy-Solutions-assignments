package com.example;

class S1{
	public static String Set(String x, String y) {
		System.out.println("id : "+x+" name: "+y);
		return x + " " + y;
	}
}

public class TestDemo3 extends S1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set("1","Archit");
	}

}