package com.example;

public class PassengerDetails {
	private String passengerName;
	private int age;
	private String gender;
	public PassengerDetails() {
		System.out.println("default constructor invoked!!!");
	}
	public PassengerDetails(String passengerName,String gender,int age) {
		this.passengerName = passengerName;
		this.gender = gender;
		this.age = age;
	}
	void display() {
		System.out.println(passengerName + "           " + gender + "   " + age);
	}
}
