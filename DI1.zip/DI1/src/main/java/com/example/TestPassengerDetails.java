package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestPassengerDetails {
	public static void main(String[] args) {
		Resource rs = new ClassPathResource("appContext.xml");
		BeanFactory factory = new XmlBeanFactory(rs);
		System.out.println(" *Passsenger Details* \n");
		System.out.println("PassengerName" + " " + "Gender" + " " + "Age");

		PassengerDetails p_details = (PassengerDetails) factory.getBean("passenger1");
		p_details.display();
		PassengerDetails p_details1 = (PassengerDetails) factory.getBean("passenger2");
		p_details1.display();
	}
}