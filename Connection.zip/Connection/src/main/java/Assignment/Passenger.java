package Assignment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Passenger {
	private static String name;
	private static int age;
	private static char gender;
	static Connection con;
	boolean b;
	public Passenger(String name, int age, char gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
		//b = insertPassdetails();
	}
	public Passenger() {
		super();
	}
	 public static int insertPassdetails(String name1, int age1, char gender1) throws SQLException {
		 try {
			 con = DbCon.create("train");
			String q = "INSERT INTO passenger (name,age,gender)VALUES('"+name1+"',"+age1+",'"+gender1+"');";
			//System.out.println(q);
			Statement st = con.createStatement();
			int update = st.executeUpdate(q);
			//System.out.println(update+"'s rows changerd 0.001s");
			
			String qry = "select * from passenger where name='"+name1+"' AND age ="+age1+";";
			java.sql.Statement stmt  = con.createStatement();	
			ResultSet rs = st.executeQuery(qry);
			while(rs.next())
				return rs.getInt(1);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con != null)
				con.close();
		}
		 
		 return -1;
	 }
	 
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
}
