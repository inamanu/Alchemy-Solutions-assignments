package Assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

public class DbCon {
		static Connection con;
		public static Connection create(String db) throws ClassNotFoundException {
			try {
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/"+db;
				String usr = "root";
				String pass = "admin";
			
				con = DriverManager.getConnection(url, usr, pass);
				return con;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}
}