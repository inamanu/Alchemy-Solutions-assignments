$(document).ready( function () {
    
    $("#gettrains").click(function(event){
        $("#trainaddform").hide();
        $('#trainupdateform').hide();
        $('#traindeleteform').hide();
        getTrains();
        $('#t_table').show();
        });
        
        function getTrains(){
            const api_url ="http://localhost:8080/api/trains";
            async function getapi(url) {
              let options = {
                method:'GET'
            }
              const response = await fetch(url,options);
              var data = await response.json();
              console.log(data);
              show(data);
          }
          getapi(api_url);
          function show(data) {
          let tab =
            `<tr>
            <th>Train Number</th>
            <th>Train Name</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Ticket Price</th>
            </tr>`;
              for (let r of data) {
                tab += `<tr>
              <td>${r.trainNo} </td>
              <td>${r.trainName}</td>
              <td>${r.source}</td>
              <td>${r.destination}</td>
              <td>${r.ticketPrice}</td>		
            </tr>`;
              }
              document.getElementById("train_table").innerHTML = tab;
          }
        }

    $("#addtrain").click(function() {
        $("#t_table").hide();
        $('#trainupdateform').hide();
        $('#traindeleteform').hide();
        $('#trainaddform').show();
        });

     $("#add").click(function() {
        var trainNo = document.getElementById("trainno").value;
        trainNo = parseInt(trainNo);
        var trainName = document.getElementById("trainname").value;
        var source = document.getElementById("source").value;
        var destination = document.getElementById("destination").value;
        var ticketPrice = document.getElementById("ticketprice").value;
        ticketPrice = parseInt(ticketPrice);
    
        //alert(p_name + " " + age + " " + gender);
    
        var data = {
            "trainNo":trainNo,
            "trainName":trainName,
            "source":source,
            "destination":destination,
            "ticketPrice":ticketPrice
        }

        if(data.trainNo!="" && data.trainName!="" && data.source!="" && data.destination!="" && data.ticketPrice!=""){
        //console.log(JSON.stringify(data));
        let options = {
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify(data)
        }
    
        let fres = fetch("http://localhost:8080/api/trains",options);
        fres.then(res => res.json()).then(d => {
            console.log("success"+ d);
        })
        alert("Train Data Added Successfully");
        document.getElementById("trainaddform").reset();
        $("#trainaddform").hide();
        }//if
        else{
            alert("Invalid Data or Data Missing");
        }
    } );

    $("#updatetrain").click(function() {
      $("#t_table").hide();
      $('#trainaddform').hide();
      $('#traindeleteform').hide();
      $('#trainupdateform').show();
  });

  $("#update").click(function() {
    var trainNo = document.getElementById("trainnou").value;
    trainNo = parseInt(trainNo);
    var trainName = document.getElementById("trainnameu").value;
    var source = document.getElementById("sourceu").value;
    var destination = document.getElementById("destinationu").value;
    var ticketPrice = document.getElementById("ticketpriceu").value;
    ticketPrice = parseInt(ticketPrice);

    var data = {
        "trainNo":trainNo,
        "trainName":trainName,
        "source":source,
        "destination":destination,
        "ticketPrice":ticketPrice
    }

    if(data.trainNo!="" && data.trainName!="" && data.source!="" && data.destination!="" && data.ticketPrice!=""){
  //console.log(JSON.stringify(data));
  let options = {
      method:'PUT',
      headers:{
          'Content-Type':'application/json'
      },
      body:JSON.stringify(data)
  }

  let fres = fetch("http://localhost:8080/api/trains",options);
  fres.then(res => res.json()).then(d => {
      console.log("success"+ d);
  })
  alert("Train Data Updated Successfully");
  document.getElementById("trainupdateform").reset();
  $("#trainupdateform").hide();
  }//if
  else{
      alert("Invalid Data or Data Missing");
  }  
  });

  $("#deletetrain").click(function() {
      $('#trainaddform').hide();
      $('#trainupdateform').hide();
      $('#traindeleteform').show();
      $("#t_table").show();
  });

  $("delete").click(function() {
    var tno=document.getElementById("t_no").value;
            let options = {
            method:'DELETE'
        }

        let fres = fetch("http://localhost:8080/api/trains/"+tno,options);
        console.log("Success"+fres)
      alert("Train delete Successfully")
  });
} );