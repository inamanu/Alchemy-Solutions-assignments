$(document).ready( function () {

    $("#add").click(function(){
    
        var email = document.getElementById("email").value;
        var pwd = document.getElementById("password").value;
        //alert(email + " " + pwd)
        if(email!="" && pwd!=""){
        var data = {
            "email":email,
            "password":pwd
        }
        //console.log(JSON.stringify(data));
        let options = {
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify(data)
        }

        let fres = fetch("http://localhost:8080/api/users",options);
        fres.then(res => res.json()).then(d => {
            console.log("success"+ d);
        })

        document.getElementById("signup-form").reset();
        alert("Welcome, Sign In Successfully\nGo To Passenger Tab to Book Ticket");
        var url = "file:///C:\Users\naman\eclipse-workspace\TrainTicketReservation-1\src\main\resources\templates\passenger.html";
          //$(location).attr('href',url);
        }//if
        else{
            alert("Enter Valid Data!!");
        }
    });
});