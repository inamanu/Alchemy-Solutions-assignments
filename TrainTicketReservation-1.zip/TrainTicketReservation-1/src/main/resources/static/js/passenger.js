$(document).ready( function () {

    $("#getpassengers").click(function(event) {
            $("#passengeraddform").hide();
            $('#passengerupdateform').hide();
            $('#passengerdeleteform').hide();
            getPassengers();
    });

    function getPassengers(){
        const api_url ="http://localhost:8080/api/passengers";
        async function getapi(url) {
          let options = {
            method:'GET'
        }
          const response = await fetch(url,options);
          var data = await response.json();
          console.log(data);
          show(data);
      }
      getapi(api_url);
      function show(data) {
      let tab =
        `<tr>
        <th>Id</th>
        <th>Passenger Name</th>
        <th>Age</th>
        <th>Gender</th>
        </tr>`;
          for (let r of data) {
            tab += `<tr>
          <td>${r.id} </td>
          <td>${r.p_name}</td>
          <td>${r.age}</td>
          <td>${r.gender}</td>		
        </tr>`;
          }
          document.getElementById("passenger_table").innerHTML = tab;
      }
      $('#p_table').show();
    }

    $("#addpassenger").click(function() {
        $("#p_table").hide();
        $('#passengerupdateform').hide();
        $('#passengerdeleteform').hide();
        $('#passengeraddform').show();
      });

    $("#add").click(function() {
    var p_name = document.getElementById("p_name").value;
    var age = document.getElementById("age").value;
    var gender = $("input[name='gender']:checked").val();

    //alert(p_name + " " + age + " " + gender);

    var data = {
        "p_name":p_name,
        "age":age,
        "gender":gender
    }
    if(data.p_name!="" && data.age!="" && data.gender!=""){
    //console.log(JSON.stringify(data));
    let options = {
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify(data)
    }

    let fres = fetch("http://localhost:8080/api/passengers",options);
    fres.then(res => res.json()).then(d => {
        console.log("success"+ d);
    })
    alert("Passenger Data Added Successfully");
    document.getElementById("passengeraddform").reset();
    $("#passengeraddform").hide();
    }//if
    else{
        alert("Invalid Data or Data Missing");
    }  
} );

    $("#updatepassenger").click(function() {
        $("#p_table").hide();
        $('#passengeraddform').hide();
        $('#passengerdeleteform').hide();
        $('#passengerupdateform').show();
    });

    $("#update").click(function() {
        var p_name = document.getElementById("p_nameu").value;
        var age = document.getElementById("ageu").value;
        var gender = $("input[name='genderu']:checked").val();

    //alert(p_name + " " + age + " " + gender);

    var data = {
        "id":50,
        "p_name":p_name,
        "age":age,
        "gender":gender
    }
    if(data.p_name!="" && data.age!="" && data.gender!=""){
    //console.log(JSON.stringify(data));
    let options = {
        method:'PUT',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify(data)
    }

    let fres = fetch("http://localhost:8080/api/passengers",options);
    fres.then(res => res.json()).then(d => {
        console.log("success"+ d);
    })
    alert("Passenger Data Updated Successfully");
    document.getElementById("passengeraddform").reset();
    $("#passengerupdateform").hide();
    }//if
    else{
        alert("Invalid Data or Data Missing");
    }  
    });

    $("#deletepassenger").click(function() {
        $('#passengeraddform').hide();
        $('#passengerupdateform').hide();
        $('#passengerdeleteform').show();
        $("#p_table").show();
    });

    $("#delete").click(function() {
        var p_id = document.getElementById("p_id").value;
            let options = {
            method:'DELETE'
        }

        let fres = fetch("http://localhost:8080/api/passengers/"+p_id,options);
        console.log("Success"+fres)
        alert("Passenger delete Successfully")
    });
});