$(document).ready( function () {

    $("#gettickets").click(function(event) {
        //$("#passengeraddform").hide();
        getTickets();
        $('#t_table').show();
});

function getTickets(){
    const api_url ="http://localhost:8080/api/tickets";
    async function getapi(url) {
      let options = {
        method:'GET'
    }
      const response = await fetch(url,options);
      var data = await response.json();
      console.log(data);
      show(data);
  }
  getapi(api_url);
  function show(data) {
  let tab =
    `<tr>
    <th>Id</th>
    <th>Passenger Id</th>
    <th>PNR</th>
    <th>Train No.</th>
    <th>Travel Date</th>
    </tr>`;
      for (let r of data) {
        tab += `<tr>
      <td>${r.counter} </td>
      <td>${r.p_id}</td>
      <td>${r.pnr}</td>
      <td>${r.trainNo}</td>
      <td>${r.travel_date}</td>		
    </tr>`;
      }
      document.getElementById("ticket_table").innerHTML = tab;
  }
}

    $("#bookticket").click(function(){
        $("#t_table").hide();
        $('#ticketaddform').show();
      });

    $("#book").click(function() {
    var p_name = document.getElementById("p_name").value;
    var age = document.getElementById("age").value;
    var gender = $("input[name='gender']:checked").val();
    var source = document.getElementById("source").value;
    var destination = document.getElementById("destination").value;
    var travel_date = document.getElementById("traveldate").value;
    var pnr = "MUM_2021_100";
    //alert(p_name + " " + age + " " + gender);
    //gettrainNo
    var train_no = getTrainNo();

    var passenger_data = {
        "p_name":p_name,
        "age":age,
        "gender":gender
    }
    if(passenger_data.p_name!="" && passenger_data.age!="" && passenger_data.gender!=""){
    //console.log(JSON.stringify(data));
    let passenger_data_post = {
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify(passenger_data)
    }

    let fres1 = fetch("http://localhost:8080/api/passengers",passenger_data_post);
    fres1.then(res => res.json()).then(d => {
        console.log("success"+ d);
    })

    var p_id = getP_id();

    ticket_data={
      "p_id":1,
      "pnr":pnr,
      "train_no":train_no,
      "travel_date":travel_date
    }
    //POST in to ticket table
    let ticket_data_post = {
      method:'POST',
      headers:{
          'Content-Type':'application/json'
      },
      body:JSON.stringify(ticket_data)
  }

  let fres2 = fetch("http://localhost:8080/api/tickets",ticket_data_post);
  fres2.then(res => res.json()).then(d => {
      console.log("success"+ d);
    })
    alert("Booking Successfully");
    document.getElementById("ticketaddform").reset();
    $("#ticketaddform").hide();
    $('#t_table').show();
    }//if
    else{
        alert("Invalid Data or Data Missing");
    }
} );

    $("#downloadticket").click(function(){
        alert("Ticket Dowmloaded Successfully");
    });

    function getTrainNo(){

    }

    function getP_id(){

    }
});