package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tickets")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "pnr")
	private String pnr;
	@Column(name = "travel_date")
	private String travel_date;
	@Column(name = "p_id")
	private int p_id;
	@Column(name = "trainNo")
	private int trainNo;
	
	Ticket(){
	}
	
	public Ticket(String pnr, String travel_date, int p_id, int trainNo) {
		super();
		this.pnr = pnr;
		this.travel_date = travel_date;
		this.p_id = p_id;
		this.trainNo = trainNo;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	public String getTravel_date() {
		return travel_date;
	}
	public void setTravel_date(String travel_date) {
		this.travel_date = travel_date;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	@Override
	public String toString() {
		return "Ticket [id=" + id + ", pnr=" + pnr + ", travel_date=" + travel_date + ", p_id=" + p_id
				+ ", trainNo=" + trainNo + "]";
	}
}