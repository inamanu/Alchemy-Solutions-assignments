package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, String>{

	Optional<Passenger> findById(int id);

	void deleteById(int id);

	//void deleteById(int id);

}
