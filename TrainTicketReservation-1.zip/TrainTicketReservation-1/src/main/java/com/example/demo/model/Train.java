package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trains")
public class Train {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "train_no")
	private String train_no;
	@Column(name = "train_name")
	private	String train_name;
	@Column(name = "source")
	private String source;
	@Column(name = "destination")
	private String destination;
	@Column(name = "ticket_price")
	private int ticket_price;
	
	Train(){
	}
	
	public Train(String train_no,String train_name,String source,String destination,int ticket_price) {
		super();
		this.train_no = train_no;
		this.train_name = train_name;
		this.source = source;
		this.destination = destination;
		this.ticket_price = ticket_price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTrainNo() {
		return train_no;
	}

	public void setTrainNo(String train_no) {
		this.train_no = train_no;
	}

	public String getTrainName() {
		return train_name;
	}

	public void setTrainName(String train_name) {
		this.train_name = train_name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getTicketPrice() {
		return ticket_price;
	}

	public void setTicketPrice(int ticket_price) {
		this.ticket_price = ticket_price;
	}

	@Override
	public String toString() {
		return "Train [id=" + id + ", train_no=" + train_no + ", train_name=" + train_name + ", source=" + source
				+ ", destination=" + destination + ", ticket_price=" + ticket_price + "]";
	}
}