package com.example.bean;

public class Train {

}
