var counter = 1;
$(document).ready(function() {
validationDetails();

//Add row to DataTable
var t = $('#etable').DataTable();
$('#submit').on('click', function () {
	//if($("#check").valid()==true){
		var age = calculateAge();
		var ename = $('#ename').val();
		var department = $('#department').val();
		var dateofbirth = $('#dateofbirth').val();
		var gender = $("input[name='gender']:checked").val()
		var isrtor = $("input[name='isrtor']:checked").val()
		var keyskills = $('#keyskills').val();
		var dateofjoining = $('#dateofjoining').val();
		var yoe = $('#yoe').val();
		if(isrtor== undefined)
			isrtor = "No";
		//t.row($('#ebody').parents('tr')).remove().draw();
		if(age=="" ||  ename=="" || department==""  || dateofbirth=="" || gender=="" || isrtor=="" || keyskills=="" || dateofjoining=="" || yoe=="" ){
			alert( "Valid: " + "Please Enter All Fields");
			validationDetails();
		}//if
		else{
			t.row.add( [
				counter,ename,department,dateofbirth,age,gender,isrtor,keyskills,dateofjoining,yoe] ).draw( true );
		}//else
		counter++;
} );

});//Document End