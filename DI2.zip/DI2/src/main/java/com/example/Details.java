package com.example;

public class Details {
	private String p_name;
	private int p_age;
	private String p_add;
	
	public Details() {
		System.out.println("Inside default");
	}
	public Details(String p_name, int p_age,String p_add) {
		this.p_name = p_name;
		this.p_age = p_age;
		this.p_add = p_add;
	}
	void display() {
		System.out.println(p_name+" "+p_age+" "+p_add);
	}
}
