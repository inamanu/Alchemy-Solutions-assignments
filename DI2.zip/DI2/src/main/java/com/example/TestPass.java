package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestPass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource rs = new ClassPathResource("appContext.xml");
		BeanFactory factory = new XmlBeanFactory(rs);
		
		Details d1 = (Details) factory.getBean("passBean1");
		d1.display();
		Details d2 = (Details) factory.getBean("passBean2");
		d2.display();
	}

}
