package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestTrain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource rs = new ClassPathResource("applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(rs);
		Train train = (Train)factory.getBean("trainBean1");
		train.display();
	}

}
