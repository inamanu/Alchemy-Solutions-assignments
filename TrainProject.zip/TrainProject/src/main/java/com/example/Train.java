package com.example;

public class Train {
	private int trainNo;
	private String traineName;
	private String source;
	private String destination;
	private Double ticketprice;
	
	
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	public String getTraineName() {
		return traineName;
	}
	public void setTraineName(String traineName) {
		this.traineName = traineName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Double getTicketprice() {
		return ticketprice;
	}
	public void setTicketprice(Double ticketprice) {
		this.ticketprice = ticketprice;
	}
	public void display() {
		System.out.println(trainNo+" "+traineName+" "+source+" "+destination+" "+ticketprice);
	}
}
